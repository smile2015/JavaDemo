package com.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.beans.AccountBean;

/**
 * 登录页面拦截器
 * @author Administrator
 *
 */
public class LoginFilter implements Filter {

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {

		// 在过滤器中检查是否已经登录

		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse resp = (HttpServletResponse) response;

		AccountBean account = (AccountBean) req.getSession().getAttribute("account");
		
		//如果请求AccountBean为空即未登录或并且请求url不是以index.html结尾并且不是以CheckAccount（注：servlet）结尾,将请求跳转到index.html页面
		//即未登录如果访问其他页面则自动跳转到登录页面，必须登录后才能进行访问
		if (account == null && !req.getRequestURI().endsWith("index.html")
				&& !req.getRequestURI().endsWith("CheckAccount")) {
			resp.sendRedirect("index.html"); 
		
//			req.getRequestDispatcher("index.html").forward(request, response);
		} else {
			chain.doFilter(request, response);
		}

	}

	@Override
	public void destroy() {

	}

}