package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * 
 * @author Administrator
 *
 */
//@WebServlet("/EchartsServlet")
public class EchartsServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	@SuppressWarnings("unused")
	@Override
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		//设置response响应头格式
		//解决中文乱码问题
		response.setContentType("application/json-rpc;charset=utf-8");
		// response.setHeader("Cache-Control", "no-cache");
		// response.setHeader("Expires", "0");
		// response.setHeader("Pragma", "No-cache");
		// response.setHeader("Access-Control-Allow-Origin", "*");
		// response.setHeader("Access-Control-Allow-Credentials","true");
		// response.setHeader("Access-Control-Allow-Headers",
		// "*, X-Requested-With, Content-Type");
		response.setHeader("Access-Control-Allow-Methods",
				"GET, OPTIONS, POST, DELETE, PUT");
		response.setHeader("Content-Type: text/html", "charset=UTF-8");
		
		
		
		String[] categories = { "衬衫", "羊毛衫", "雪纺衫", "裤子", "高跟鞋", "袜子" };
		Integer[] values = { 5, 20, 36, 10, 10, 20 };
		
		String[] categories2 = { "衬衫", "羊毛衫", "雪纺衫", "裤子", "高跟鞋", "袜子" };
		Integer[] values2 = { 30, 60, 32, 30, 10,50 };
		
		/*
		 * js怎么遍历我后台传过来的Map？？
		 * 答：
		 * 首先，你说的是后台传来，并且是map，并且用js方式。这有两个情况：
		 * 
		 * map 的值是实体类，无法遍历每条实体类的内部（js拿到键值对的值，是内存引用地址） map 的值不是实体类，可以通过 var map =
		 * JSON.parse('${变量名}')；//转为json，注意要有引号 for ( var i in map) { // i是索引
		 * var obj = map[i]; } ============= 针对第一种情况，2个方法： 1.
		 * 后台先转为json字符串，再传给前端； 2. 通过类似java的<c:foreach这样的后台语言操作。
		 */
//		Map<String, Object> map = new HashMap<String, Object>();
//		map.put("categories", categories);
//		map.put("values", values);
		
		
		//使用json将数据进行封装
		 JSONObject json = new JSONObject();
		 try {
		 json.put("categories", categories);
		 json.put("values", values);
		 json.put("categories2", categories2);
		 json.put("values2", values2);
		 } catch (JSONException e) {
		 e.printStackTrace();
		 }

		if (json != null) {
			PrintWriter writer = response.getWriter();
			writer.write(json.toString());
			// writer.print(json);

			System.out.println(json);
			writer.flush();
			writer.close();
		} else {
			response.getWriter().print(1);
		}

	}

}
