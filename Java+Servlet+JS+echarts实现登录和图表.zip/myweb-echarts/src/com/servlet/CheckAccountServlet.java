package com.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.beans.AccountBean;


public class CheckAccountServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doGet(req, resp);
	}

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		HttpSession session = req.getSession();
		AccountBean account = new AccountBean();
		String username = req.getParameter("username");
		String pwd = req.getParameter("password");
		account.setPassword(pwd);
		account.setUsername(username);
		if ((username != null) && (username.trim().equals("admin"))) {
			if ((pwd != null) && (pwd.trim().equals("123456"))) {
				System.out.println("success");
				session.setAttribute("account", account);
				String login_suc = "print.html";
				resp.sendRedirect(login_suc);
				return;
			}
		}
		String login_fail = "index.html";
		System.out.println("failed");
		resp.sendRedirect(login_fail);
		return ;
	}

}