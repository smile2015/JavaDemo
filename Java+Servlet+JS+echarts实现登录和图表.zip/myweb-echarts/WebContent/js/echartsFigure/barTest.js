// 基于准备好的dom，初始化echarts实例
        var myChart = echarts.init(document.getElementById('main'));
		
        var categories = [];
		var values = [];
		
		// 同步执行
		$.ajaxSettings.async = false;
		
		// 加载数据
	
		$.getJSON('EchartsServlet', function (json) {
			categories = json.categories;
			values = json.values;
		});
		
        // 指定图表的配置项和数据
        var option = {
            title: {
                text: 'ECharts 入门示例'
            },
            tooltip: {},
            legend: {
                data:['销量']
            },
            xAxis: {
                data: categories
            },
            yAxis: {},
            series: [{
                name: '销量',
                type: 'bar',
                data: values
            }]
        };

        // 使用刚指定的配置项和数据显示图表。
        myChart.setOption(option);